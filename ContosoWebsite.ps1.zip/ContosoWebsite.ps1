Configuration ContosoWebsite
{
  param ($MachineName)
	

  Node $MachineName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = �Present�
      Name = �Web-Server�
    }

	xWebSite 'DefaultCompanySite' {

            Name = 'CompanySite'

            BindingInfo = @( MSFT_xWebBindingInformation

                {

                    Protocol = 'HTTP'

                    Port = 8080

                }

            )

            PhysicalPath = 'C:\inetpub\wwwroot'

            ApplicationPool = 'CompanyAppPool'

            DependsOn = '[xWebAppPool]DefaultCompanyAppPool'

        }

 

        xWebAppPool 'DefaultCompanyAppPool' {

            Name = 'CompanyAppPool'

        }

    }

  }
} 